"""
Alpaca API Configuration
"""

# Your Alpaca API credentials
ALPACA_API_KEY = "PKZYW6TVQTBGJ45O72JCE2O7AJ"
ALPACA_API_SECRET = "Fj99jf8GHEUrk8FcqYS6LL2AxR5CA22k1BMi5Xa6xcdi"
